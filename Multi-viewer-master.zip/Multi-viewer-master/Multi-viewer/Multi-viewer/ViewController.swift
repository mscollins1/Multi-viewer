//
//  ViewController.swift
//  Multi-viewer
//
//  Created by Mike Scollins on 11/25/18.
//  Copyright © 2018 Mike Scollins. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

